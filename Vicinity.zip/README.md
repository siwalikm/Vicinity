# Vicinity
A python based app which lets you transfer files within computers in the same network, using Simple Hand Gestures
